from flask import Flask, render_template, request, redirect, url_for
import json
from utils import find_closest_location

app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/", methods=["POST"])
def locate():
    try:
        data = json.loads(request.form["wifi_data"])
        location = find_closest_location(data)
        return render_template("result.html", location=location)
    except Exception as e:
        error_message = f"Error: {str(e)}"
        return render_template("result.html", location=error_message)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
