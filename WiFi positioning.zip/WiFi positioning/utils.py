import json
import os

FINGERPRINT_DIR = "fingerprint_db"

def load_fingerprints():
    db = {}
    for filename in os.listdir(FINGERPRINT_DIR):
        if filename.endswith(".json"):
            path = os.path.join(FINGERPRINT_DIR, filename)
            with open(path, "r") as f:
                data = json.load(f)
                db[filename.replace(".json", "")] = data
    return db

def calculate_similarity(input_data, db_data):
    input_map = {ap["BSSID"]: ap["RSSI"] for ap in input_data}
    db_map = {ap["BSSID"]: ap["RSSI"] for ap in db_data}
    
    common = set(input_map.keys()) & set(db_map.keys())
    if not common:
        return float("inf")
    
    distance = 0
    for bssid in common:
        distance += (input_map[bssid] - db_map[bssid]) ** 2
    return distance ** 0.5

def find_closest_location(input_data):
    db = load_fingerprints()
    best_match = None
    best_score = float("inf")
    
    for location, db_data in db.items():
        score = calculate_similarity(input_data, db_data)
        if score < best_score:
            best_score = score
            best_match = location
    return best_match
